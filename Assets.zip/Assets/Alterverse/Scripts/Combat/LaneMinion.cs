using Alterverse.Characters;using UnityEngine;
namespace Alterverse.Combat
{
[RequireComponent(typeof(Health))]public sealed class LaneMinion:MonoBehaviour
{
[SerializeField]private float moveSpeed=2.8f,detectionRange=7.5f,attackRange=1.85f,attackDamage=3.25f,attackCooldown=1.35f;private Health health,target;private int team;private Alterverse.Match.DimensionsFront front;private float structureDamageMultiplier=1f,frontInfluenceOnDeath;private bool siegeUnit;public bool IsSiegeUnit=>siegeUnit;private Vector3 destination;public Vector3 LaneDestination=>destination;private float nextAttackTime,nextScanTime,nextRouteScan;private string waveGroupKey;private int waveSlot;private float regroupGraceUntil;private RealityCore routeCore;private bool routeBlocked;public int Team=>team;public void ConfigureFrontInfluence(float percent)=>frontInfluenceOnDeath=Mathf.Max(0f,percent);public void ConfigureSiegeRole(bool enabled=true)=>siegeUnit=enabled;public void ConfigureCombat(float speed,float detection,float range,float damage,float cooldown,float vsStructures=1f){moveSpeed=speed;detectionRange=detection;attackRange=range;attackDamage=damage;attackCooldown=cooldown;structureDamageMultiplier=Mathf.Max(1f,vsStructures);}private void Awake(){gameObject.layer=GameplayCollision.Units;health=GetComponent<Health>();front=FindAnyObjectByType<Alterverse.Match.DimensionsFront>();if(health!=null)health.Died+=OnDied;}private void OnDestroy(){if(health!=null)health.Died-=OnDied;}private void OnDied(){if(frontInfluenceOnDeath<=0f)return;front??=FindAnyObjectByType<Alterverse.Match.DimensionsFront>();if(front!=null)front.Push(team==0?1:0,frontInfluenceOnDeath);}public void Initialize(int teamId,Vector3 laneDestination){team=teamId;destination=laneDestination;nextAttackTime=Time.time+Random.Range(.2f,.65f);}
public void ConfigureWaveGroup(string unitKey,int slot)
{
    if(string.IsNullOrEmpty(unitKey))return;
    int marker=unitKey.LastIndexOf(":I");
    waveGroupKey=marker>0?unitKey.Substring(0,marker):unitKey;
    waveSlot=Mathf.Max(0,slot);
    regroupGraceUntil=Time.time+2.5f;
}
private void Update(){if(!Alterverse.Multiplayer.CoopAuthority.CanSimulateHostGameplay)return;if(Time.timeScale<=0f||health==null||health.IsDead||!HeroCombatStatus.CanAct(gameObject))return;if(front!=null&&front.HasEnded)return;if(TryRegroup()){target=null;return;}if(!IsValidTarget(target))target=null;if(Time.time>=nextScanTime){target=FindTarget();nextScanTime=Time.time+.2f;}if(target!=null){Vector3 delta=target.transform.position-transform.position;delta.y=0;float range=(target.GetComponent<LaneTower>()!=null||target.GetComponent<RealityCore>()!=null)?2.4f:attackRange;if(delta.sqrMagnitude<=range*range){Face(delta);if(Time.time>=nextAttackTime){nextAttackTime=Time.time+attackCooldown;GetComponent<Alterverse.Visuals.LaneUnitVisualMotion>()?.PulseAttack();float dealt=(target.GetComponent<LaneTower>()!=null||target.GetComponent<RealityCore>()!=null)?attackDamage*structureDamageMultiplier:attackDamage;target.TakeDamage(dealt,gameObject);Alterverse.Visuals.PrototypeVfx.ProjectileLine(transform.position+Vector3.up*.15f,target.transform.position+Vector3.up*.15f,team==0?new Color(.76f,.24f,1f):new Color(.18f,.92f,1f),.065f);}return;}MoveTowards(target.transform.position);return;}

    // Siege mechs must always advance when combat is not actively holding them in range.
    // They deliberately bypass the ordinary wave's bastion/core route gate: their lane destination
    // is authoritative, and FindPriorityStructure will still pick up a nearby tower/core to fight.
    if(siegeUnit){AdvanceSiegeLane();return;}

    if(Time.time>=nextRouteScan){nextRouteScan=Time.time+.2f;routeCore=FindEnemyCore();routeBlocked=HasEnemyBastion();}if(!routeBlocked&&routeCore!=null&&routeCore.IsVulnerable){MoveTowards(routeCore.transform.position);return;}MoveTowards(destination);}
private bool TryRegroup()
{
    if(siegeUnit||string.IsNullOrEmpty(waveGroupKey))return false;

    LaneMinion leader=null;
    float bestX=team==0?float.NegativeInfinity:float.PositiveInfinity;
    for(int i=0;i<Health.Active.Count;i++)
    {
        Health hp=Health.Active[i];
        if(hp==null||hp.IsDead)continue;
        LaneMinion other=hp.GetComponent<LaneMinion>();
        if(other==null||other.team!=team||other.siegeUnit||other.waveGroupKey!=waveGroupKey)continue;
        float x=other.transform.position.x;
        if((team==0&&x>bestX)||(team==1&&x<bestX)){bestX=x;leader=other;}
    }

    if(leader==null||leader==this)return false;
    float behind=team==0?leader.transform.position.x-transform.position.x:transform.position.x-leader.transform.position.x;
    bool assembly=Time.time<regroupGraceUntil;
    if(!assembly&&behind<2.15f)return false;

    Vector3 slot=leader.transform.position;
    float rear=.85f+Mathf.Max(0,waveSlot-1)*.55f;
    slot.x+=team==0?-rear:rear;
    slot.z=destination.z+(waveSlot-1)*.72f;
    slot.y=transform.position.y;
    MoveTowards(slot,1.55f);
    return true;
}

private void AdvanceSiegeLane()
{
    Vector3 lanePoint=destination;
    lanePoint.y=transform.position.y;
    MoveTowards(lanePoint);
}
private bool IsValidTarget(Health candidate){if(candidate==null||candidate.IsDead||!candidate.isActiveAndEnabled)return false;
LaneMinion minion=candidate.GetComponent<LaneMinion>();LaneTower tower=candidate.GetComponent<LaneTower>();RealityCore core=candidate.GetComponent<RealityCore>();TeamMember member=candidate.GetComponent<TeamMember>();
bool enemy=minion!=null?minion.Team!=team:tower!=null?tower.Team!=team:core!=null?core.Team!=team&&core.IsVulnerable:member!=null&&member.Team!=team;
if(!enemy)return false;Vector3 d=candidate.transform.position-transform.position;d.y=0;return d.sqrMagnitude<=detectionRange*detectionRange*1.45f;}
private Health FindTarget(){if(siegeUnit){Health structure=FindPriorityStructure();if(structure!=null)return structure;}Health waveOpponent=FindOpposingMinion();if(waveOpponent!=null)return waveOpponent;Health best=null;float bestScore=float.MaxValue,maxSqr=detectionRange*detectionRange;for(int index=0;index<Health.Active.Count;index++){Health candidate=Health.Active[index];if(candidate==null||candidate==health||candidate.IsDead)continue;bool enemy=false;float priority=1f;LaneMinion minion=candidate.GetComponent<LaneMinion>();if(minion!=null){enemy=minion.Team!=team;priority=.42f;}else{LaneTower tower=candidate.GetComponent<LaneTower>();if(tower!=null){enemy=tower.Team!=team;priority=siegeUnit?.28f:.78f;}else{RealityCore core=candidate.GetComponent<RealityCore>();if(core!=null){enemy=core.Team!=team&&core.IsVulnerable;priority=.9f;}else{TeamMember member=candidate.GetComponent<TeamMember>();if(member!=null){enemy=member.Team!=team;priority=1.15f;}}}}if(!enemy)continue;Vector3 delta=candidate.transform.position-transform.position;delta.y=0;float sqr=delta.sqrMagnitude;if(sqr>maxSqr)continue;float lanePenalty=1f+Mathf.Abs(delta.z)*.12f;float score=sqr*priority*lanePenalty;if(score<bestScore){bestScore=score;best=candidate;}}return best;}
private Health FindPriorityStructure(){Health best=null;float bestSqr=detectionRange*detectionRange;for(int index=0;index<Health.Active.Count;index++){LaneTower tower=Health.Active[index].GetComponent<LaneTower>();if(tower==null||tower.Team==team)continue;Health hp=tower.GetComponent<Health>();if(hp==null||hp.IsDead)continue;Vector3 d=tower.transform.position-transform.position;d.y=0;if(Mathf.Abs(tower.transform.position.z-destination.z)>6f||d.sqrMagnitude>bestSqr)continue;bestSqr=d.sqrMagnitude;best=hp;}if(best!=null)return best;RealityCore core=FindEnemyCore();if(core==null||!core.IsVulnerable)return null;Health coreHp=core.GetComponent<Health>();if(coreHp==null||coreHp.IsDead)return null;Vector3 delta=core.transform.position-transform.position;delta.y=0;return delta.sqrMagnitude<=bestSqr?coreHp:null;}
private Health FindOpposingMinion()
{
// Keep a live wave opponent until it dies or leaves detection range.
if(IsValidTarget(target)){LaneMinion current=target.GetComponent<LaneMinion>();if(current!=null&&current.Team!=team)return target;}
Health closest=null;float nearest=detectionRange*detectionRange;
for(int index=0;index<Health.Active.Count;index++)
{
Health hp=Health.Active[index];if(hp==null||hp.IsDead)continue;
LaneMinion other=hp.GetComponent<LaneMinion>();
if(other==null||other==this||other.Team==team)continue;
Vector3 delta=other.transform.position-transform.position;delta.y=0;
if(delta.sqrMagnitude<nearest){nearest=delta.sqrMagnitude;closest=hp;}
}
return closest;
}
private bool HasEnemyBastion(){for(int index=0;index<Health.Active.Count;index++){LaneTower tower=Health.Active[index].GetComponent<LaneTower>();if(tower==null||tower.Team==team)continue;Health h=tower.GetComponent<Health>();if(h==null||h.IsDead)continue;/* Only the bastion on this minion's lane blocks its route. The other lane must not hold this wave hostage. */if(Mathf.Abs(tower.transform.position.z-transform.position.z)<6f)return true;}return false;}private RealityCore FindEnemyCore(){for(int index=0;index<Health.Active.Count;index++){RealityCore core=Health.Active[index].GetComponent<RealityCore>();if(core!=null&&core.Team!=team)return core;}return null;}
private void MoveTowards(Vector3 point,float speedMultiplier=1f){Vector3 direction=point-transform.position;direction.y=0;if(direction.sqrMagnitude<.16f)return;float distance=direction.magnitude;direction.Normalize();transform.position+=direction*Mathf.Min(moveSpeed*Mathf.Max(.1f,speedMultiplier)*HeroCombatStatus.Speed(gameObject)*Time.deltaTime,distance);Face(direction);}private void Face(Vector3 direction){direction.y=0;if(direction.sqrMagnitude>.001f)transform.rotation=Quaternion.Slerp(transform.rotation,Quaternion.LookRotation(direction),10*Time.deltaTime);}
}
}

