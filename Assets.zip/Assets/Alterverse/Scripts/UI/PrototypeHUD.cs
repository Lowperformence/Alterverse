using Alterverse.Characters;
using Alterverse.Combat;
using Alterverse.Visuals;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.EnhancedTouch;
using ETouch=UnityEngine.InputSystem.EnhancedTouch.Touch;
namespace Alterverse.UI
{
    // Keep the component name for existing bootstrap/scene compatibility.
    [DefaultExecutionOrder(-200)]
    public sealed class PrototypeHUD:MonoBehaviour
    {
        private Health health;
        private BasicAttack attack;
        private HeroMotor motor;
        private PlayerHeroAbilities abilities;
        private HeroIdentity identity;
        private Camera view;
        private FrontEndTheme theme;
        private GUIStyle centered,small;
        private readonly string[] names=new string[4],descriptions=new string[4],details=new string[4];
        private readonly CombatGlyph[] glyphs=new CombatGlyph[4];
        private string heroName,statusText="",feedback="",healthText="";
        private AbilityButtonView buttonView;
        private float pressStarted=-10f;
        private float nextReadout;
        private float feedbackUntil,damageTrail=1,damageHold,previousHp=1;
        private bool focused=true,suspended,combatInside;
        private int joystickFinger=-1,combatFinger=-1,pressedSlot=-1,inspectedSlot=-1;
        private bool mouseJoystick;
        private Vector2 joystickCenter,joystickOrigin,joystickKnob;
        private const float Radius=CombatHudLayout.JoystickRadius;
        private CombatHudLayout layout;
        private Rect previousSafe;
        private Color accent;
        private Texture2D joystickOuterTexture,joystickThumbTexture;
        public void Initialize(Health player,VeyrAbilities legacyAbilities,Health enemy)
        {
            health=player;if(player==null)return;
            if (player.GetComponent<AbilityRangePreviewOverlay>() == null)
                player.gameObject.AddComponent<AbilityRangePreviewOverlay>();
            attack=player.GetComponent<BasicAttack>();motor=player.GetComponent<HeroMotor>();
            abilities=player.GetComponent<PlayerHeroAbilities>();identity=player.GetComponent<HeroIdentity>();view=Camera.main;
            heroName=identity!=null?identity.DisplayName.ToUpperInvariant():"HERO";
            accent=identity!=null?StylizedArtDirection.HeroAccent(identity.Hero):FrontEndTheme.Accent;
            damageTrail=health.Normalized;CacheAbilities();
            buttonView?.Dispose();buttonView=new AbilityButtonView(transform,identity!=null?identity.Hero:HeroId.Veyr);
        }
        private void CacheAbilities()
        {
            if(abilities==null)return;
            for(int i=0;i<4;i++)
            {
                AbilitySpec spec=abilities.SpecFor(i);names[i]=spec.Name.ToUpperInvariant();descriptions[i]=abilities.Describe(i);
                details[i]=$"RANGE {abilities.PreviewRange(i):0.#}m  ·  AUTO TARGET";glyphs[i]=GlyphFor(i);
            }
        }
        private CombatGlyph GlyphFor(int slot)
        {
            HeroId h=identity!=null?identity.Hero:HeroId.Veyr;
            if(h==HeroId.Veyr)return slot==0?CombatGlyph.NullCut:slot==1?CombatGlyph.Rift:slot==2?CombatGlyph.Dash:CombatGlyph.Execute;
            if(h==HeroId.Kaelon)return slot==0?CombatGlyph.Impact:slot==1?CombatGlyph.Shield:slot==2?CombatGlyph.Gravity:CombatGlyph.Citadel;
            if(h==HeroId.Nyra)return slot==0?CombatGlyph.PrismShot:slot==1?CombatGlyph.Dash:slot==2?CombatGlyph.Snare:CombatGlyph.Volley;
            if(h==HeroId.Elyra)return slot==0?CombatGlyph.OrbitFracture:slot==1?CombatGlyph.Invert:slot==2?CombatGlyph.Phase:CombatGlyph.Singularity;
            if(h==HeroId.Mira)return slot==0?CombatGlyph.Seed:slot==1?CombatGlyph.Heal:slot==2?CombatGlyph.Shelter:CombatGlyph.Wildsurge;
            if(h==HeroId.Rook)return slot==0?CombatGlyph.Swing:slot==1?CombatGlyph.Armor:slot==2?CombatGlyph.Slam:CombatGlyph.Overdrive;
            if(h==HeroId.Traveler)return slot==0?CombatGlyph.ChronoBeam:slot==1?CombatGlyph.TimeStep:slot==2?CombatGlyph.ChronoField:CombatGlyph.Paradox;
            return CombatGlyph.ChronoBeam;
        }
        private void OnEnable()=>EnhancedTouchSupport.Enable();
        private void OnDestroy()
        {
            buttonView?.Dispose();
            if(joystickOuterTexture!=null)Destroy(joystickOuterTexture);
            if(joystickThumbTexture!=null)Destroy(joystickThumbTexture);
        }
        private void OnDisable(){buttonView?.SetVisible(false);ResetInput();if(EnhancedTouchSupport.enabled)EnhancedTouchSupport.Disable();}
        private void OnApplicationFocus(bool value){focused=value;if(!value){buttonView?.SetVisible(false);ResetInput();}}
        private void OnApplicationPause(bool value){suspended=value;if(value){buttonView?.SetVisible(false);ResetInput();}}
        private void ResetInput(){joystickFinger=combatFinger=pressedSlot=inspectedSlot=-1;mouseJoystick=false;combatInside=false;motor?.SetMoveInput(Vector2.zero);}
        private void Update()
        {
            layout=new CombatHudLayout(Screen.safeArea);
            if(previousSafe!=layout.Safe){previousSafe=layout.Safe;ResetInput();}
            if(layout.Safe.width<=0||layout.Safe.height<=0||Time.timeScale<=0||health==null||health.IsDead||!focused||suspended){buttonView?.SetVisible(false);ResetInput();return;}
            float hp=health.Normalized;
            if(hp<previousHp)damageHold=Time.unscaledTime+.25f;previousHp=hp;
            if(hp>damageTrail)damageTrail=hp;
            if(hp<damageTrail&&Time.unscaledTime>=damageHold)damageTrail=Mathf.MoveTowards(damageTrail,hp,Time.unscaledDeltaTime*.7f);
            HeroCombatStatus status=health.GetComponent<HeroCombatStatus>();
            statusText=status!=null&&status.Stunned?"STUNNED":status!=null&&status.MoveMultiplier<.99f?"SLOWED":"";
            HandleTouches();
            // A touch gesture exclusively owns touch controls; the mouse path is for editor/desktop testing.
            if(ETouch.activeTouches.Count==0&&combatFinger<0)HandleMouse();
            if(Time.unscaledTime>=nextReadout)
            {
                nextReadout=Time.unscaledTime+.1f;
                healthText=$"{health.Current:0} / {health.Max:0}"+(health.Shield>0?$"   +{health.Shield:0} SHIELD":"");

            }
        }
        private void LateUpdate()
        {
            bool visible=layout.Safe.width>0&&layout.Safe.height>0&&Time.timeScale>0&&health!=null&&!health.IsDead&&focused&&!suspended;
            buttonView?.SetVisible(visible);
            if(!visible||buttonView==null)return;
            buttonView.Layout(layout);
            bool blocked=!HeroCombatStatus.CanAct(health.gameObject);
            for(int i=0;i<5;i++)
            {
                float remaining=i<4?(abilities!=null?abilities.RemainingFor(i):0):(attack!=null?attack.RemainingCooldown:0);
                float duration=i<4?(abilities!=null?abilities.CooldownFor(i):1):(attack!=null?attack.AttackCooldown:1);
                bool unavailable=blocked||(i<4?abilities==null:attack==null);
                buttonView.SetState(i,remaining,duration,unavailable,pressedSlot==i&&combatInside,pressedSlot==i?Time.unscaledTime-pressStarted:10);
            }
        }
        private void HandleTouches()
        {
            bool foundMove=false,foundCombat=false;
            var touches=ETouch.activeTouches;
            // Resolve all movement before any combat release, regardless of finger order.
            for(int i=0;i<touches.Count;i++)
            {
                var touch=touches[i];Vector2 point=layout.Point(touch.screenPosition);
                bool ended=touch.phase==UnityEngine.InputSystem.TouchPhase.Ended,canceled=touch.phase==UnityEngine.InputSystem.TouchPhase.Canceled;
                if(touch.phase==UnityEngine.InputSystem.TouchPhase.Began)
                {
                    if(layout.Hit(point)<0&&joystickFinger<0&&layout.MoveCapture.Contains(point))
                    {joystickFinger=touch.touchId;joystickOrigin=point;joystickCenter=new Vector2(Mathf.Clamp(point.x,Radius+12,layout.Width-Radius-12),Mathf.Clamp(point.y,Radius+12,layout.Height-Radius-12));joystickKnob=joystickCenter;}
                }
                if(touch.touchId==joystickFinger)
                {
                    foundMove=true;
                    if(ended||canceled){joystickFinger=-1;motor?.SetMoveInput(Vector2.zero);}
                    else
                    {
                        Vector2 delta=Vector2.ClampMagnitude(point-joystickOrigin,Radius);joystickKnob=joystickCenter+delta;
                        float magnitude=delta.magnitude/Radius;
                        Vector2 input=magnitude<=.08f?Vector2.zero:delta.normalized*Mathf.Clamp01((magnitude-.08f)/.92f);
                        motor?.SetMoveInput(new Vector2(input.x,-input.y));
                    }
                }
            }
            if(!foundMove&&joystickFinger>=0){joystickFinger=-1;motor?.SetMoveInput(Vector2.zero);}
            for(int i=0;i<touches.Count;i++)
            {
                var touch=touches[i];Vector2 point=layout.Point(touch.screenPosition);
                bool ended=touch.phase==UnityEngine.InputSystem.TouchPhase.Ended,canceled=touch.phase==UnityEngine.InputSystem.TouchPhase.Canceled;
                if(touch.phase==UnityEngine.InputSystem.TouchPhase.Began&&combatFinger<0&&pressedSlot<0)
                {
                    int slot=layout.Hit(point);
                    if(slot>=0){combatFinger=touch.touchId;BeginPress(slot);}
                }
                if(touch.touchId==combatFinger)
                {
                    foundCombat=true;combatInside=layout.ContainsWithMargin(pressedSlot,point);
                    if(ended||canceled){EndPress(!canceled&&combatInside);combatFinger=-1;}
                    else if(pressedSlot==4&&combatInside)attack?.TryAttack();
                }
            }
            if(!foundCombat&&combatFinger>=0){EndPress(false);combatFinger=-1;}
        }
        private void HandleMouse()
        {
            Mouse mouse=Mouse.current;if(mouse==null)return;
            Vector2 point=layout.Point(mouse.position.ReadValue());

            if(mouse.leftButton.wasPressedThisFrame)
            {
                int slot=layout.Hit(point);
                if(slot>=0)BeginPress(slot);
                else if(layout.MoveCapture.Contains(point))
                {
                    mouseJoystick=true;
                    joystickOrigin=point;
                    joystickCenter=new Vector2(Mathf.Clamp(point.x,Radius+12,layout.Width-Radius-12),Mathf.Clamp(point.y,Radius+12,layout.Height-Radius-12));
                    joystickKnob=joystickCenter;
                }
            }

            if(mouseJoystick)
            {
                if(mouse.leftButton.isPressed)
                {
                    Vector2 delta=Vector2.ClampMagnitude(point-joystickOrigin,Radius);
                    joystickKnob=joystickCenter+delta;
                    float magnitude=delta.magnitude/Radius;
                    Vector2 input=magnitude<=.08f?Vector2.zero:delta.normalized*Mathf.Clamp01((magnitude-.08f)/.92f);
                    motor?.SetMoveInput(new Vector2(input.x,-input.y));
                }
                if(mouse.leftButton.wasReleasedThisFrame)
                {
                    mouseJoystick=false;
                    motor?.SetMoveInput(Vector2.zero);
                }
                return;
            }

            if(pressedSlot<0)return;
            combatInside=layout.ContainsWithMargin(pressedSlot,point);
            if(mouse.leftButton.wasReleasedThisFrame)EndPress(combatInside);
            else if(pressedSlot==4&&combatInside&&mouse.leftButton.isPressed)attack?.TryAttack();
        }
        private void BeginPress(int slot)
        {
            pressedSlot=slot;combatInside=true;inspectedSlot=slot<4?slot:-1;pressStarted=Time.unscaledTime;
            if(slot==4)attack?.TryAttack();
        }
        private void EndPress(bool commit)
        {
            int slot=pressedSlot;pressedSlot=-1;inspectedSlot=-1;
            if(!commit||slot<0||slot>3||abilities==null)return;
            bool success=slot==0?abilities.CastQ():slot==1?abilities.CastW():slot==2?abilities.CastE():abilities.CastUltimate();
            if(success){feedback=names[slot];Alterverse.Audio.UiSoundRouter.Confirm();}
            else if(!HeroCombatStatus.CanAct(health.gameObject))feedback="STUNNED — CANNOT CAST";
            else if(abilities.RemainingFor(slot)>0)feedback="ABILITY RECHARGING";
            else if(glyphs[slot]==CombatGlyph.Heal||glyphs[slot]==CombatGlyph.Shelter||glyphs[slot]==CombatGlyph.Shield||glyphs[slot]==CombatGlyph.Wildsurge)feedback="NO ELIGIBLE ALLY / ALREADY PROTECTED";
            else feedback="NO TARGET / PATH BLOCKED";
            feedbackUntil=Time.unscaledTime+1.5f;nextReadout=0;
        }
        private void OnGUI()
        {
            if(layout.Safe.width<=0||layout.Safe.height<=0||Time.timeScale<=0||health==null||health.IsDead||!focused||suspended)return;
            layout=new CombatHudLayout(Screen.safeArea);if(layout.Safe.width<=0||layout.Safe.height<=0)return;
            theme??=new FrontEndTheme();centered??=new GUIStyle(theme.Body){alignment=TextAnchor.MiddleCenter,fontSize=14};
            small??=new GUIStyle(centered){fontSize=12};
            Matrix4x4 matrix=GUI.matrix;Color color=GUI.color;
            try
            {
                GUI.matrix=layout.Matrix;
                if(Event.current.type!=EventType.Repaint)return;
                DrawPreview();DrawHealth();DrawJoystick();DrawHint();
            }
            finally{GUI.matrix=matrix;GUI.color=color;}
        }
        private void DrawHealth()
        {
            Rect r=new Rect(16,16,218,76);theme.Panel(r);
            FrontEndTheme.Fill(new Rect(r.x+12,r.y+3,r.width-24,1),FrontEndTheme.Accent);
            theme.Label(new Rect(r.x+12,r.y+5,194,24),heroName,centered);
            Rect bar=new Rect(r.x+12,r.y+34,194,9);
            FrontEndTheme.Fill(new Rect(bar.x-1,bar.y-1,bar.width+2,bar.height+2),new Color(FrontEndTheme.Accent.r,FrontEndTheme.Accent.g,FrontEndTheme.Accent.b,.55f));
            FrontEndTheme.Fill(bar,FrontEndTheme.Background);
            FrontEndTheme.Fill(new Rect(bar.x,bar.y,bar.width*damageTrail,bar.height),new Color(.72f,.76f,.82f,.58f));
            FrontEndTheme.Fill(new Rect(bar.x,bar.y,bar.width*health.Normalized,bar.height),health.Normalized<.3f?new Color(.95f,.43f,.32f):accent);
            if(health.Shield>0)
            {
                Rect shield=new Rect(bar.x,bar.y+11,bar.width*Mathf.Clamp01(health.Shield/health.Max),3);
                FrontEndTheme.Fill(shield,FrontEndTheme.Accent);
            }
            theme.Label(new Rect(r.x+12,r.y+48,194,22),healthText,small);
            if(statusText.Length>0)
            {
                Rect status=new Rect(r.x+28,r.yMax+4,r.width-56,23);
                FrontEndTheme.Fill(status,new Color(FrontEndTheme.Surface.r,FrontEndTheme.Surface.g,FrontEndTheme.Surface.b,.92f));
                FrontEndTheme.Fill(new Rect(status.x,status.y,status.width,1),statusText=="STUNNED"?new Color(.96f,.48f,.32f):new Color(.86f,.72f,.34f));
                theme.Label(status,statusText,centered);
            }
        }
        private void DrawJoystick()
        {
            bool active=joystickFinger>=0||mouseJoystick;
            Vector2 center=active?joystickCenter:layout.JoystickIdle;
            Vector2 knob=active?joystickKnob:center;
            EnsureJoystickTextures();

            // Draw each joystick part as one anti-aliased circle texture.
            // This avoids the segmented/ribbed look caused by CombatGlyphs.Ring line segments.
            Color before=GUI.color;
            GUI.color=new Color(1f,1f,1f,active?.36f:.22f);
            GUI.DrawTexture(new Rect(center.x-Radius,center.y-Radius,Radius*2,Radius*2),joystickOuterTexture,ScaleMode.StretchToFill,true);

            GUI.color=new Color(.90f,.90f,.90f,active?.36f:.22f);
            GUI.DrawTexture(new Rect(knob.x-CombatHudLayout.ThumbRadius,knob.y-CombatHudLayout.ThumbRadius,CombatHudLayout.ThumbRadius*2,CombatHudLayout.ThumbRadius*2),joystickThumbTexture,ScaleMode.StretchToFill,true);
            GUI.color=before;
        }

        private void EnsureJoystickTextures()
        {
            if(joystickOuterTexture==null)joystickOuterTexture=BuildJoystickCircleTexture(256,true);
            if(joystickThumbTexture==null)joystickThumbTexture=BuildJoystickCircleTexture(128,false);
        }

        private static Texture2D BuildJoystickCircleTexture(int size,bool outlineOnly)
        {
            Texture2D texture=new Texture2D(size,size,TextureFormat.RGBA32,false,true)
            {
                name=outlineOnly?"DF_JoystickOuterCircle":"DF_JoystickThumbCircle",
                filterMode=FilterMode.Bilinear,
                wrapMode=TextureWrapMode.Clamp,
                hideFlags=HideFlags.HideAndDontSave
            };
            Color32[] pixels=new Color32[size*size];
            float center=(size-1)*.5f;
            // Cached analytic circle coverage; no segmented line drawing.
            float radius=size*.5f-2f;
            float stroke=size*(outlineOnly?1.25f/(Radius*2):.9f/(CombatHudLayout.ThumbRadius*2));

            for(int y=0;y<size;y++)
            for(int x=0;x<size;x++)
            {
                float dx=x-center,dy=y-center;
                float distance=Mathf.Sqrt(dx*dx+dy*dy);
                // Flat fill and a single thin outline. Only the boundary pixels are
                // antialiased; no radial gradient, glow or additional disc is drawn.
                float outer=Mathf.Clamp01(radius+.5f-distance);
                float inner=Mathf.Clamp01(radius-stroke+.5f-distance);
                float alpha=outer-(outlineOnly?1f:.25f)*inner;

                pixels[y*size+x]=new Color32(255,255,255,(byte)Mathf.RoundToInt(Mathf.Clamp01(alpha)*255f));
            }

            texture.SetPixels32(pixels);
            texture.Apply(false,true);
            return texture;
        }

        private void DrawHint()
        {
            if(inspectedSlot<0)
            {
                if(Time.unscaledTime<feedbackUntil)
                {
                    Rect message=new Rect(layout.Width-410,layout.Height-290,390,28);
                    theme.Panel(message);theme.Label(message,feedback,centered);
                }
                return;
            }
            Rect r=new Rect(layout.Width-418,layout.Height-386,394,130);theme.Panel(r);
            theme.Label(new Rect(r.x+12,r.y+6,r.width-24,24),names[inspectedSlot],theme.Button);
            theme.Label(new Rect(r.x+14,r.y+34,r.width-28,42),descriptions[inspectedSlot],small);
            string detail=glyphs[inspectedSlot]==CombatGlyph.Dash?"DIRECTION: MOVE / AUTO EVADE · COLLISION MAY SHORTEN":details[inspectedSlot];
            theme.Label(new Rect(r.x+12,r.y+80,r.width-24,18),detail,small,true);
            theme.Label(new Rect(r.x+12,r.y+103,r.width-24,20),combatInside?"RELEASE TO CAST · DRAG OUT TO CANCEL":"RELEASE TO CANCEL",small);
        }
        private void ProjectLine(Vector3 from, Vector3 to, Color color, float width)
        {
            Vector3 a = view.WorldToScreenPoint(from);
            Vector3 b = view.WorldToScreenPoint(to);
            if (a.z <= 0f || b.z <= 0f)
                return;

            CombatGlyphs.Line(layout.Point(new Vector2(a.x, a.y)),
                layout.Point(new Vector2(b.x, b.y)), width, color);
        }

        private void DrawPreview()
        {
            // The smooth ground overlay owns range presentation; retain the legacy fallback only
            // for scenes without that component, avoiding two superimposed range outlines.
            AbilityRangePreviewOverlay overlay = health != null ? health.GetComponent<AbilityRangePreviewOverlay>() : null;
            if (overlay != null && overlay.isActiveAndEnabled) return;
            if (inspectedSlot < 0 || !combatInside || abilities == null)
                return;
            if (view == null)
                view = Camera.main;
            if (view == null)
                return;

            float range = abilities.PreviewRange(inspectedSlot);
            if (range <= 0f)
                return;

            Vector3 center = health.transform.position;
            center.y = .18f;
            Color tint = (glyphs[inspectedSlot] == CombatGlyph.Heal ||
                glyphs[inspectedSlot] == CombatGlyph.Shelter ||
                glyphs[inspectedSlot] == CombatGlyph.Wildsurge)
                ? new Color(.45f, .87f, .66f)
                : FrontEndTheme.Accent;

            if (glyphs[inspectedSlot] == CombatGlyph.Dash)
            {
                Vector3 direction = abilities.PreviewDirection(inspectedSlot);
                direction.y = 0f;
                direction.Normalize();
                Vector3 end = center + direction * range;
                Vector3 side = Vector3.Cross(Vector3.up, direction) * .42f;
                Color glow = new Color(tint.r, tint.g, tint.b, .18f);
                Color core = new Color(tint.r, tint.g, tint.b, .92f);
                ProjectLine(center, end, glow, 10f);
                ProjectLine(end, end - direction * .72f + side, glow, 10f);
                ProjectLine(end, end - direction * .72f - side, glow, 10f);
                ProjectLine(center, end, core, 3f);
                ProjectLine(end, end - direction * .72f + side, core, 3f);
                ProjectLine(end, end - direction * .72f - side, core, 3f);
                return;
            }

            float pulse = .5f + .5f * Mathf.Sin(Time.unscaledTime * 5.5f);
            Color outer = new Color(tint.r, tint.g, tint.b, .13f + pulse * .05f);
            Color inner = new Color(tint.r, tint.g, tint.b, .84f);
            const int segments = 40;
            for (int i = 0; i < segments; i++)
            {
                float a = i * Mathf.PI * 2f / segments;
                float b = (i + 1) * Mathf.PI * 2f / segments;
                Vector3 p = center + new Vector3(Mathf.Cos(a), 0f, Mathf.Sin(a)) * range;
                Vector3 q = center + new Vector3(Mathf.Cos(b), 0f, Mathf.Sin(b)) * range;
                ProjectLine(p, q, outer, 9f);
                ProjectLine(p, q, inner, 2.5f);
            }

            AbilitySpec spec = abilities.SpecFor(inspectedSlot);
            if (spec.Radius > .01f)
            {
                Health target = GetComponent<SoftTargeting>()?.Current;
                Vector3 areaCenter = target != null
                    ? target.transform.position
                    : center + transform.forward * Mathf.Min(range * .65f, range - spec.Radius);
                areaCenter.y = .20f;
                Color areaTint = new Color(tint.r, tint.g, tint.b, .75f);
                for (int i = 0; i < 32; i++)
                {
                    float a = i * Mathf.PI * 2f / 32f;
                    float b = (i + 1) * Mathf.PI * 2f / 32f;
                    Vector3 p = areaCenter + new Vector3(Mathf.Cos(a), 0f, Mathf.Sin(a)) * spec.Radius;
                    Vector3 q = areaCenter + new Vector3(Mathf.Cos(b), 0f, Mathf.Sin(b)) * spec.Radius;
                    ProjectLine(p, q, new Color(tint.r, tint.g, tint.b, .12f), 7f);
                    ProjectLine(p, q, areaTint, 2f);
                }
            }
        }
    }
}


